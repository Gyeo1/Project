clc;
clear;
zero=-5; %3���� zeor�� ����

p_1=[0.5*cos(pi/4)+0.5j*sin(pi/4) 0.5*cos(pi/4)-0.5j*sin(pi/4)];
p_2=[cos(pi/4)+1j*sin(pi/4) cos(pi/4)-1j*sin(pi/4)];
p_3=[1.5*cos(pi/4)+1.5j*sin(pi/4) 1.5*cos(pi/4)-1.5j*sin(pi/4)];

%����  �Լ�
[b1,a1]=zp2tf(zero,p_1,1);
[b2,a2]=zp2tf(zero,p_2,1);
[b3,a3]=zp2tf(zero,p_3,1);
%�κкм�ȭ
[r1,p1,k1]=residue(b1,a1);
[r2,p2,k2]=residue(b2,a2);
[r3,p3,k3]=residue(b3,a3);
t=linspace(0,20,21);

s1=h_t(r1,p1,t,1);
s2=h_t(r2,p2,t,1);
s3=h_t(r3,p3,t,1);
figure(1)
subplot(311)
stem(t,s1,'k');
grid on

subplot(312)
stem(t,s2,'k');
grid on

subplot(313)
stem(t,s3,'k');
grid on
